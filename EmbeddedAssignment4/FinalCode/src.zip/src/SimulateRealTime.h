#pragma once
class RealTimeExecution;

class SimulateRealTime
{
public:
	SimulateRealTime();
	virtual ~SimulateRealTime();
//	virtual void RunRealTime() = 0;
//	virtual void Simulate() = 0;
//	virtual void RunSimulation(RealTimeExecution* client) = 0;
};
