#include "SimulateRealTime.h"

SimulateRealTime::SimulateRealTime()
{
}

SimulateRealTime::~SimulateRealTime()
{
}
