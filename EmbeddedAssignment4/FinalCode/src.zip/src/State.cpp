#include "State.h"

State::State()
= default;

State::~State()
= default;
