#include "ApplicationModeSetting.h"

ApplicationModeSetting::ApplicationModeSetting()
{
}

ApplicationModeSetting::~ApplicationModeSetting()
{
}
