#include "Operational.h"


Operational::Operational()
= default;

Operational::~Operational()
= default;
